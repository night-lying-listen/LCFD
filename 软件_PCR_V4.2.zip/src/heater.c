#include "heater.h"

tmr_output_config_type tmr_oc_init_structure;

void tmr3_pwm_gpio_init(void)
{
	
  gpio_init_type gpio_init_struct;

  gpio_default_para_init(&gpio_init_struct);
	crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);		//ʹ������ʱ��
  gpio_init_struct.gpio_pins = GPIO_PINS_6 | GPIO_PINS_7 | GPIO_PINS_8 | GPIO_PINS_9;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;		//�������
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init(GPIOC, &gpio_init_struct);

  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE6, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE7, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE8, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE9, GPIO_MUX_2);
}


//crm_clocks_freq_type crm_clocks_freq_struct = {0};
uint16_t tmr3_ccr1_val = 0;
uint16_t tmr3_ccr2_val = 0;
uint16_t tmr3_ccr3_val = 0;
uint16_t tmr3_ccr4_val = 0;
void tmr3_init(void)
{
	/* tmr3 clock enable */
  crm_periph_clock_enable(CRM_TMR3_PERIPH_CLOCK, TRUE);	//TMR3ʱ��ʹ��

	/* tmr3 time base configuration */
  tmr_base_init(TMR3, 999, 143);		//��ʼ��TMR3������Ϊ1000,Ԥ��Ƶϵ��Ϊ143�����Ƶ��Ϊ1000Hz
  tmr_cnt_dir_set(TMR3, TMR_COUNT_UP);				//���ϼ���
  tmr_clock_source_div_set(TMR3, TMR_CLOCK_DIV1);		//TMR3��Ƶ

  tmr_output_default_para_init(&tmr_oc_init_structure);
  tmr_oc_init_structure.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_A;
  tmr_oc_init_structure.oc_idle_state = FALSE;
  tmr_oc_init_structure.oc_polarity = TMR_OUTPUT_ACTIVE_HIGH;
  tmr_oc_init_structure.oc_output_state = TRUE;
  tmr_output_channel_config(TMR3, TMR_SELECT_CHANNEL_1, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR3, TMR_SELECT_CHANNEL_1, tmr3_ccr1_val);
  tmr_output_channel_buffer_enable(TMR3, TMR_SELECT_CHANNEL_1, TRUE);

  tmr_output_channel_config(TMR3, TMR_SELECT_CHANNEL_2, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR3, TMR_SELECT_CHANNEL_2, tmr3_ccr2_val);
  tmr_output_channel_buffer_enable(TMR3, TMR_SELECT_CHANNEL_2, TRUE);

  tmr_output_channel_config(TMR3, TMR_SELECT_CHANNEL_3, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR3, TMR_SELECT_CHANNEL_3, tmr3_ccr3_val);
  tmr_output_channel_buffer_enable(TMR3, TMR_SELECT_CHANNEL_3, TRUE);

  tmr_output_channel_config(TMR3, TMR_SELECT_CHANNEL_4, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR3, TMR_SELECT_CHANNEL_4, tmr3_ccr4_val);
  tmr_output_channel_buffer_enable(TMR3, TMR_SELECT_CHANNEL_4, TRUE);

  tmr_period_buffer_enable(TMR3, TRUE);

  /* tmr enable counter */
  tmr_counter_enable(TMR3, TRUE);
}

void tmr4_pwm_gpio_init(void)
{
  gpio_init_type gpio_init_struct;

  gpio_default_para_init(&gpio_init_struct);
	crm_periph_clock_enable(CRM_GPIOB_PERIPH_CLOCK, TRUE);		//ʹ������ʱ��
  gpio_init_struct.gpio_pins = GPIO_PINS_6 | GPIO_PINS_7 | GPIO_PINS_8 | GPIO_PINS_9;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init(GPIOB, &gpio_init_struct);

  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE6, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE7, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE8, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE9, GPIO_MUX_2);
}


uint16_t tmr4_ccr1_val = 0;
uint16_t tmr4_ccr2_val = 0;
uint16_t tmr4_ccr3_val = 0;
uint16_t tmr4_ccr4_val = 0;
void tmr4_init(void)
{
	/* tmr5 clock enable */
  crm_periph_clock_enable(CRM_TMR4_PERIPH_CLOCK, TRUE);	//TMR5ʱ��ʹ��
		
	/* tmr5 time base configuration */
  tmr_base_init(TMR4, 999, 143);		//��ʼ��TMR5������Ϊ1000,Ԥ��Ƶϵ��Ϊ144�����Ƶ��Ϊ1000Hz
  tmr_cnt_dir_set(TMR4, TMR_COUNT_UP);				//���ϼ���
  tmr_clock_source_div_set(TMR4, TMR_CLOCK_DIV1);		//TMR5��Ƶ

  tmr_output_default_para_init(&tmr_oc_init_structure);
  tmr_oc_init_structure.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_A;
  tmr_oc_init_structure.oc_idle_state = FALSE;
  tmr_oc_init_structure.oc_polarity = TMR_OUTPUT_ACTIVE_HIGH;
  tmr_oc_init_structure.oc_output_state = TRUE;
  tmr_output_channel_config(TMR4, TMR_SELECT_CHANNEL_1, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR4, TMR_SELECT_CHANNEL_1, tmr4_ccr1_val);
  tmr_output_channel_buffer_enable(TMR4, TMR_SELECT_CHANNEL_1, TRUE);

  tmr_output_channel_config(TMR4, TMR_SELECT_CHANNEL_2, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR4, TMR_SELECT_CHANNEL_2, tmr4_ccr2_val);
  tmr_output_channel_buffer_enable(TMR4, TMR_SELECT_CHANNEL_2, TRUE);

  tmr_output_channel_config(TMR4, TMR_SELECT_CHANNEL_3, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR4, TMR_SELECT_CHANNEL_3, tmr4_ccr3_val);
  tmr_output_channel_buffer_enable(TMR4, TMR_SELECT_CHANNEL_3, TRUE);

  tmr_output_channel_config(TMR4, TMR_SELECT_CHANNEL_4, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR4, TMR_SELECT_CHANNEL_4,  tmr4_ccr4_val);
  tmr_output_channel_buffer_enable(TMR4, TMR_SELECT_CHANNEL_4, TRUE);

  tmr_period_buffer_enable(TMR4, TRUE);

  /* tmr enable counter */
  tmr_counter_enable(TMR4, TRUE);
}


void tmr5_pwm_gpio_init(void)
{
  gpio_init_type gpio_init_struct;

  gpio_default_para_init(&gpio_init_struct);
	crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);		//ʹ������ʱ��
  gpio_init_struct.gpio_pins = GPIO_PINS_0 | GPIO_PINS_1 | GPIO_PINS_2 | GPIO_PINS_3;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init(GPIOA, &gpio_init_struct);

  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE0, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE1, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE2, GPIO_MUX_2);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE3, GPIO_MUX_2);
}


uint16_t tmr5_ccr1_val = 0;
uint16_t tmr5_ccr2_val = 0;
uint16_t tmr5_ccr3_val = 0;
uint16_t tmr5_ccr4_val = 0;
void tmr5_init(void)
{
	/* tmr5 clock enable */
  crm_periph_clock_enable(CRM_TMR5_PERIPH_CLOCK, TRUE);	//TMR5ʱ��ʹ��
		
	/* tmr5 time base configuration */
  tmr_base_init(TMR5, 999, 143);		//��ʼ��TMR5������Ϊ1000,Ԥ��Ƶϵ��Ϊ144�����Ƶ��Ϊ1000Hz
  tmr_cnt_dir_set(TMR5, TMR_COUNT_UP);				//���ϼ���
  tmr_clock_source_div_set(TMR5, TMR_CLOCK_DIV1);		//TMR5��Ƶ

  tmr_output_default_para_init(&tmr_oc_init_structure);
  tmr_oc_init_structure.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_A;
  tmr_oc_init_structure.oc_idle_state = FALSE;
  tmr_oc_init_structure.oc_polarity = TMR_OUTPUT_ACTIVE_HIGH;
  tmr_oc_init_structure.oc_output_state = TRUE;
  tmr_output_channel_config(TMR5, TMR_SELECT_CHANNEL_1, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR5, TMR_SELECT_CHANNEL_1, tmr5_ccr1_val);
  tmr_output_channel_buffer_enable(TMR5, TMR_SELECT_CHANNEL_1, TRUE);

  tmr_output_channel_config(TMR5, TMR_SELECT_CHANNEL_2, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR5, TMR_SELECT_CHANNEL_2, tmr5_ccr2_val);
  tmr_output_channel_buffer_enable(TMR5, TMR_SELECT_CHANNEL_2, TRUE);

  tmr_output_channel_config(TMR5, TMR_SELECT_CHANNEL_3, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR5, TMR_SELECT_CHANNEL_3, tmr5_ccr3_val);
  tmr_output_channel_buffer_enable(TMR5, TMR_SELECT_CHANNEL_3, TRUE);

  tmr_output_channel_config(TMR5, TMR_SELECT_CHANNEL_4, &tmr_oc_init_structure);
  tmr_channel_value_set(TMR5, TMR_SELECT_CHANNEL_4,  tmr5_ccr4_val);
  tmr_output_channel_buffer_enable(TMR5, TMR_SELECT_CHANNEL_4, TRUE);

  tmr_period_buffer_enable(TMR5, TRUE);

  /* tmr enable counter */
  tmr_counter_enable(TMR5, TRUE);
}

void tmr1_init(void)
{
  /* enable tmr1 clock */
  crm_periph_clock_enable(CRM_TMR1_PERIPH_CLOCK, TRUE);

	/* tmr1 configuration */
  /* time base configuration */
  tmr_base_init(TMR1, 1999, 143);	//���ü������ں�Ԥ��Ƶϵ����144MHz/(143+1)=1MHz����һ����1us
																	//��1000����ʱ�жϣ��ж�ʱ��Ϊ1ms
  tmr_cnt_dir_set(TMR1, TMR_COUNT_UP);

  /* overflow interrupt enable */
  tmr_interrupt_enable(TMR1, TMR_OVF_INT, TRUE);	//ʹ������ж�

  /* tmr1 hall interrupt nvic init */
//  nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
  nvic_irq_enable(TMR1_OVF_TMR10_IRQn, 1, 0);		

  /* enable tmr1 */
  tmr_counter_enable(TMR1, TRUE);
}

