#include "ui.h"
#include "xmc_lcd.h"
#include "image.h"

void startImageShow()
{
	userShowImage(0,0,480,320,gImage_test);
}
