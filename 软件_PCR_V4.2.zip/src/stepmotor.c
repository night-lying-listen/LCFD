#include "stepmotor.h"



void stepmotorCtrlGpioInit()
{
	gpio_init_type gpio_init_struct;

  /* enable the led clock */
  crm_periph_clock_enable(CRM_GPIOD_PERIPH_CLOCK, TRUE);

  /* set default parameter */
  gpio_default_para_init(&gpio_init_struct);

  /* configure the led gpio */
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
	
  gpio_init_struct.gpio_pins = MOTOR_A_DIR_PIN | MOTOR_A_EN_PIN | MOTOR_A_STEP_PIN |\
															 MOTOR_B_DIR_PIN | MOTOR_B_EN_PIN | MOTOR_B_STEP_PIN |\
															 MOTOR_C_DIR_PIN | MOTOR_C_EN_PIN | MOTOR_C_STEP_PIN;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(GPIOD, &gpio_init_struct);
	
	gpio_bits_set(MOTOR_A_EN_GPIO,MOTOR_A_EN_PIN);//ʹ�ܵ��A��A4988����
	gpio_bits_set(MOTOR_B_EN_GPIO,MOTOR_B_EN_PIN);//ʹ�ܵ��A��A4988����
	gpio_bits_set(MOTOR_C_EN_GPIO,MOTOR_C_EN_PIN);//ʹ�ܵ��A��A4988����
	gpio_bits_set(MOTOR_C_DIR_GPIO,MOTOR_C_DIR_PIN);//ʹ�ܵ��A��A4988����


//	/* enable the led clock */
//  crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);

//  /* set default parameter */
//  gpio_default_para_init(&gpio_init_struct);

//  /* configure the led gpio */
//  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
//  gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
//  gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
//	
//  gpio_init_struct.gpio_pins = GPIO_PINS_6 | GPIO_PINS_7 | GPIO_PINS_8 | GPIO_PINS_9;
//  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
//  gpio_init(GPIOC, &gpio_init_struct);
//	gpio_bits_set(GPIOC,GPIO_PINS_6);
//	gpio_bits_reset(GPIOC,GPIO_PINS_7);
//	gpio_bits_reset(GPIOC,GPIO_PINS_8);
//	gpio_bits_reset(GPIOC,GPIO_PINS_9);
}

void actuatorGpioInit(void)		//�綯�Ƹ����ų�ʼ��
{
	gpio_init_type gpio_init_struct;

  /* enable the led clock */
  crm_periph_clock_enable(ACTUATORA_F_GPIO_CRM_CLK, TRUE);

  /* set default parameter */
  gpio_default_para_init(&gpio_init_struct);

  /* configure the led gpio */
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
	
  gpio_init_struct.gpio_pins = ACTUATORA_F_PIN | ACTUATORA_R_PIN | ACTUATORB_F_PIN | ACTUATORB_R_PIN ;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(ACTUATORA_F_GPIO, &gpio_init_struct);
	
	gpio_bits_reset(ACTUATORA_F_GPIO,ACTUATORA_F_PIN);
	gpio_bits_reset(ACTUATORA_R_GPIO,ACTUATORA_R_PIN);
	gpio_bits_reset(ACTUATORB_F_GPIO,ACTUATORB_F_PIN);
	gpio_bits_reset(ACTUATORB_R_GPIO,ACTUATORB_R_PIN);
}