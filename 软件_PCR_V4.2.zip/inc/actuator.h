#ifndef __ACTUATOR_H_
#define __ACTUATOR_H_
#include "at32f435_437_int.h"

#define ACTUATORA_F_PIN                  				GPIO_PINS_12
#define ACTUATORA_F_GPIO                      	GPIOB
#define ACTUATORA_F_GPIO_CRM_CLK              	CRM_GPIOB_PERIPH_CLOCK

#define ACTUATORA_R_PIN                  				GPIO_PINS_13
#define ACTUATORA_R_GPIO                      	GPIOB
#define ACTUATORA_R_GPIO_CRM_CLK              	CRM_GPIOB_PERIPH_CLOCK

#define ACTUATORB_F_PIN                  				GPIO_PINS_14
#define ACTUATORB_F_GPIO                      	GPIOB
#define ACTUATORB_F_GPIO_CRM_CLK              	CRM_GPIOB_PERIPH_CLOCK

#define ACTUATORB_R_PIN                  				GPIO_PINS_15
#define ACTUATORB_R_GPIO                      	GPIOB
#define ACTUATORB_R_GPIO_CRM_CLK              	CRM_GPIOB_PERIPH_CLOCK

#define ACTUATORC_F_PIN                  				GPIO_PINS_10
#define ACTUATORC_F_GPIO                      	GPIOD
#define ACTUATORC_F_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORC_R_PIN                  				GPIO_PINS_11
#define ACTUATORC_R_GPIO                      	GPIOD
#define ACTUATORC_R_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORD_F_PIN                  				GPIO_PINS_12
#define ACTUATORD_F_GPIO                      	GPIOD
#define ACTUATORD_F_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORD_R_PIN                  				GPIO_PINS_13
#define ACTUATORD_R_GPIO                      	GPIOD
#define ACTUATORD_R_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORE_F_PIN                  				GPIO_PINS_8
#define ACTUATORE_F_GPIO                      	GPIOD
#define ACTUATORE_F_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORE_R_PIN                  				GPIO_PINS_9
#define ACTUATORE_R_GPIO                      	GPIOD
#define ACTUATORE_R_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK




#define ACTUATORG_R_PIN                  				GPIO_PINS_14
#define ACTUATORG_R_GPIO                      	GPIOD
#define ACTUATORG_R_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORH_R_PIN                  				GPIO_PINS_15
#define ACTUATORH_R_GPIO                      	GPIOD
#define ACTUATORH_R_GPIO_CRM_CLK              	CRM_GPIOD_PERIPH_CLOCK

#define ACTUATORA_F_TOOGLE					ACTUATORA_F_GPIO->odt ^= ACTUATORA_F_PIN
#define ACTUATORA_R_TOOGLE					ACTUATORA_R_GPIO->odt ^= ACTUATORA_R_PIN




void actuatorGpioInit(void);		//�綯�Ƹ����ų�ʼ��

void actuatoraATop(void);
void actuatoraAPos1(void);
void actuatoraAPos2(void);
void actuatoraABottomUpPos1(void);
void actuatoraAFullSqueeze(void);
void actuatoraAStop(void);
void actuatoraABottom(void);

void actuatoraBTop(void);
void actuatoraBPos1(void);
void actuatoraBPos2(void);
void actuatoraBBottomUpPos1(void);
void actuatoraBFullSqueeze(void);
void actuatoraBStop(void);
void actuatoraBBottom(void);
void actuatoraBAvoid(void);

void actuatoraCTop(void);
void actuatoraCPos1(void);
void actuatoraCPos2(void);
void actuatoraCBottomUpPos1(void);
void actuatoraCFullSqueeze(void);
void actuatoraCStop(void);
void actuatoraCBottom(void);

void actuatoraDTop(void);
void actuatoraDPos1(void);
void actuatoraDPos2(void);
void actuatoraDBottomUpPos1(void);
void actuatoraDFullSqueeze(void);
void actuatoraDStop(void);
void actuatoraDBottom(void);

void actuatoraETop(void);
void actuatoraEPos1(void);
void actuatoraEPos2(void);
void actuatoraEBottomUpPos1(void);
void actuatoraEFullSqueeze(void);
void actuatoraEStop(void);
void actuatoraEBottom(void);
#endif
