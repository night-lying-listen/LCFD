#ifndef      __XMC_LCD_H
#define	     __XMC_LCD_H

#include "at32f435_437_board.h"

#include "fonts.h"


//A16 NE1
#define  XMC_LCD_COMMAND                 ( ( uint32_t ) 0x60000000 )
#define  XMC_LCD_DATA                    ( ( uint32_t ) 0x60020000 )

#define      DEBUG_DELAY()    

//��λ����
#define      ILI9341_RST_PORT              GPIOC
#define      ILI9341_RST_PIN               GPIO_PINS_1

//��������   
#define      ILI9341_BL_PORT               GPIOC
#define      ILI9341_BL_PIN                GPIO_PINS_9

#define LCD_D0_GPIO_PORT                 GPIOD
#define LCD_D0_GPIO_CLK                  CRM_GPIOD_PERIPH_CLOCK
#define LCD_D0_GPIO_PIN                  GPIO_PINS_14
#define LCD_D0_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE14
#define LCD_D0_GPIO_MUX                  GPIO_MUX_12

#define LCD_D1_GPIO_PORT                 GPIOD
#define LCD_D1_GPIO_CLK                  CRM_GPIOD_PERIPH_CLOCK
#define LCD_D1_GPIO_PIN                  GPIO_PINS_15
#define LCD_D1_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE15
#define LCD_D1_GPIO_MUX                  GPIO_MUX_12

#define LCD_D2_GPIO_PORT                 GPIOD
#define LCD_D2_GPIO_CLK                  CRM_GPIOD_PERIPH_CLOCK
#define LCD_D2_GPIO_PIN                  GPIO_PINS_0
#define LCD_D2_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE0
#define LCD_D2_GPIO_MUX                  GPIO_MUX_12

#define LCD_D3_GPIO_PORT                 GPIOD
#define LCD_D3_GPIO_CLK                  CRM_GPIOD_PERIPH_CLOCK
#define LCD_D3_GPIO_PIN                  GPIO_PINS_1
#define LCD_D3_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE1
#define LCD_D3_GPIO_MUX                  GPIO_MUX_12

#define LCD_D4_GPIO_PORT                 GPIOE
#define LCD_D4_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D4_GPIO_PIN                  GPIO_PINS_7
#define LCD_D4_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE7
#define LCD_D4_GPIO_MUX                  GPIO_MUX_12

#define LCD_D5_GPIO_PORT                 GPIOE
#define LCD_D5_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D5_GPIO_PIN                  GPIO_PINS_8
#define LCD_D5_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE8
#define LCD_D5_GPIO_MUX                  GPIO_MUX_12

#define LCD_D6_GPIO_PORT                 GPIOE
#define LCD_D6_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D6_GPIO_PIN                  GPIO_PINS_9
#define LCD_D6_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE9
#define LCD_D6_GPIO_MUX                  GPIO_MUX_12

#define LCD_D7_GPIO_PORT                 GPIOE
#define LCD_D7_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D7_GPIO_PIN                  GPIO_PINS_10
#define LCD_D7_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE10
#define LCD_D7_GPIO_MUX                  GPIO_MUX_12

#define LCD_D8_GPIO_PORT                 GPIOE
#define LCD_D8_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D8_GPIO_PIN                  GPIO_PINS_11
#define LCD_D8_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE11
#define LCD_D8_GPIO_MUX                  GPIO_MUX_12

#define LCD_D9_GPIO_PORT                 GPIOE
#define LCD_D9_GPIO_CLK                  CRM_GPIOE_PERIPH_CLOCK
#define LCD_D9_GPIO_PIN                  GPIO_PINS_12
#define LCD_D9_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE12
#define LCD_D9_GPIO_MUX                  GPIO_MUX_12

#define LCD_D10_GPIO_PORT                GPIOE
#define LCD_D10_GPIO_CLK                 CRM_GPIOE_PERIPH_CLOCK
#define LCD_D10_GPIO_PIN                 GPIO_PINS_13
#define LCD_D10_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE13
#define LCD_D10_GPIO_MUX                 GPIO_MUX_12

#define LCD_D11_GPIO_PORT                GPIOE
#define LCD_D11_GPIO_CLK                 CRM_GPIOE_PERIPH_CLOCK
#define LCD_D11_GPIO_PIN                 GPIO_PINS_14
#define LCD_D11_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE14
#define LCD_D11_GPIO_MUX                 GPIO_MUX_12

#define LCD_D12_GPIO_PORT                GPIOE
#define LCD_D12_GPIO_CLK                 CRM_GPIOE_PERIPH_CLOCK
#define LCD_D12_GPIO_PIN                 GPIO_PINS_15
#define LCD_D12_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE15
#define LCD_D12_GPIO_MUX                 GPIO_MUX_12

#define LCD_D13_GPIO_PORT                GPIOD
#define LCD_D13_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_D13_GPIO_PIN                 GPIO_PINS_8
#define LCD_D13_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE8
#define LCD_D13_GPIO_MUX                 GPIO_MUX_12

#define LCD_D14_GPIO_PORT                GPIOD
#define LCD_D14_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_D14_GPIO_PIN                 GPIO_PINS_9
#define LCD_D14_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE9
#define LCD_D14_GPIO_MUX                 GPIO_MUX_12

#define LCD_D15_GPIO_PORT                GPIOD
#define LCD_D15_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_D15_GPIO_PIN                 GPIO_PINS_10
#define LCD_D15_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE10
#define LCD_D15_GPIO_MUX                 GPIO_MUX_12

//CS-MAIN  XMC_NE1
#define LCD_NE4_GPIO_PORT                GPIOD
#define LCD_NE4_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_NE4_GPIO_PIN                 GPIO_PINS_7
#define LCD_NE4_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE7
#define LCD_NE4_GPIO_MUX                 GPIO_MUX_12

//WR
#define LCD_NWE_GPIO_PORT                GPIOD
#define LCD_NWE_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_NWE_GPIO_PIN                 GPIO_PINS_5
#define LCD_NWE_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE5
#define LCD_NWE_GPIO_MUX                 GPIO_MUX_12

//RD
#define LCD_NOE_GPIO_PORT                GPIOD
#define LCD_NOE_GPIO_CLK                 CRM_GPIOD_PERIPH_CLOCK
#define LCD_NOE_GPIO_PIN                 GPIO_PINS_4
#define LCD_NOE_GPIO_PINS_SOURCE         GPIO_PINS_SOURCE4
#define LCD_NOE_GPIO_MUX                 GPIO_MUX_12

//RS
#define LCD_A16_GPIO_PORT                 GPIOD
#define LCD_A16_GPIO_CLK                  CRM_GPIOG_PERIPH_CLOCK
#define LCD_A16_GPIO_PIN                  GPIO_PINS_11
#define LCD_A16_GPIO_PINS_SOURCE          GPIO_PINS_SOURCE11
#define LCD_A16_GPIO_MUX                  GPIO_MUX_12
            

/***************************** ILI934 ��ʾ�������ʼ������������� ***************************/
#define      ILI9341_DispWindow_X_Star		    0     //��ʼ���X����
#define      ILI9341_DispWindow_Y_Star		    0     //��ʼ���Y����

#define 			ILI9341_LESS_PIXEL	  							480			//����
#define 			ILI9341_MORE_PIXEL	 								320			//�߶�

//����Һ��ɨ�跽����仯��XY���ؿ���
//����ILI9341_GramScan�������÷���ʱ���Զ�����
extern uint16_t LCD_X_LENGTH,LCD_Y_LENGTH; 

//Һ����ɨ��ģʽ
//������ѡֵΪ0-7
extern uint8_t LCD_SCAN_MODE;

/******************************* ���� ILI934 ��ʾ��������ɫ ********************************/
#define      BACKGROUND		                BLACK   //Ĭ�ϱ�����ɫ

#define      WHITE		 		           			 0xFFFF		 //��ɫ
#define      BLACK                         0x0000	   //��ɫ 
#define      GREY                          0xF7DE	   //��ɫ 
#define      BLUE                          0x001F	   //��ɫ 
#define      BLUE2                         0x051F	   //ǳ��ɫ 
#define      RED                           0xF800	   //��ɫ 
#define      MAGENTA                       0xF81F	   //����ɫ�����ɫ 
#define      GREEN                         0x07E0	   //��ɫ 
#define      CYAN                          0x7FFF	   //����ɫ����ɫ 
#define      YELLOW                        0xFFE0	   //��ɫ 
#define      BRED                          0xF81F
#define      GRED                          0xFFE0
#define      GBLUE                         0x07FF



/******************************* ���� ILI934 �������� ********************************/
#define      CMD_SetCoordinateX		 		    0x2A	     //����X����
#define      CMD_SetCoordinateY		 		    0x2B	     //����Y����
#define      CMD_SetPixel		 		        	0x2C	     //�������


/* ���� LCD ����оƬ ID */
#define     LCDID_UNKNOWN             0
#define     LCDID_ILI9488             0x9488
#define     LCDID_ILI9341             0x9488
#define     LCDID_ST7789V             0x8552


/********************************** ���� ILI934 ���� ***************************************/
void                     ILI9341_Init 									( void );
uint16_t                 ILI9341_ReadID                 ( void );
void                     ILI9341_Rst                    ( void );
void                     ILI9341_GramScan               ( uint8_t ucOtion );
void                     ILI9341_OpenWindow             ( uint16_t usX, uint16_t usY, uint16_t usWidth, uint16_t usHeight );
void                     ILI9341_Clear                  ( uint16_t usX, uint16_t usY, uint16_t usWidth, uint16_t usHeight );
void                     ILI9341_SetPointPixel          ( uint16_t usX, uint16_t usY );
uint16_t                 ILI9341_GetPointPixel          ( uint16_t usX , uint16_t usY );
void                     ILI9341_DrawLine               ( uint16_t usX1, uint16_t usY1, uint16_t usX2, uint16_t usY2 );
void                     ILI9341_DrawRectangle          ( uint16_t usX_Start, uint16_t usY_Start, uint16_t usWidth, uint16_t usHeight,uint8_t ucFilled );
void                     ILI9341_DrawCircle             ( uint16_t usX_Center, uint16_t usY_Center, uint16_t usRadius, uint8_t ucFilled );
void                     ILI9341_DispChar_EN            ( uint16_t usX, uint16_t usY, const char cChar );
void                     ILI9341_DispStringLine_EN      ( uint16_t line, char * pStr );
void                     ILI9341_DispString_EN      		( uint16_t usX, uint16_t usY, char * pStr );
void 					 					 ILI9341_DispString_EN_YDir 		(   uint16_t usX,uint16_t usY ,  char * pStr );

void 											LCD_SetFont											(sFONT *fonts);
sFONT 										*LCD_GetFont										(void);
void 											LCD_ClearLine										(uint16_t Line);
void 											LCD_SetBackColor								(uint16_t Color);
void 											LCD_SetTextColor								(uint16_t Color)	;
void 											LCD_SetColors										(uint16_t TextColor, uint16_t BackColor);
void 											LCD_GetColors										(uint16_t *TextColor, uint16_t *BackColor);


void 											LCD_Clear												(u16 color);
void userShowChar_FangSong(unsigned int x_start, unsigned int y_start, unsigned int offset);
void userShowChar_TimesNewRoman(unsigned int x_start, unsigned int y_start, unsigned int offset);
void userShowChar_Num(unsigned int x_start, unsigned int y_start,char * pStr);
void userShowImage(unsigned int x_start, unsigned int y_start, unsigned int width, unsigned int height,const unsigned char Img[]);
void LCD_Test(void);
static void Delay ( __IO uint32_t nCount );
#endif /* __BSP_ILI9341_ILI9341_H */


