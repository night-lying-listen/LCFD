#ifndef __STEPMOTOR_H_
#define __STEPMOTOR_H_
#include "at32f435_437_int.h"

#define MOTOR_A_EN_PIN                         GPIO_PINS_0
#define MOTOR_A_EN_GPIO                        GPIOD
#define MOTOR_A_EN_GPIO_CRM_CLK                CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_A_DIR_PIN                        GPIO_PINS_1
#define MOTOR_A_DIR_GPIO                       GPIOD
#define MOTOR_A_DIR_GPIO_CRM_CLK               CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_A_STEP_PIN                       GPIO_PINS_12
#define MOTOR_A_STEP_GPIO                      GPIOD
#define MOTOR_A_STEP_GPIO_CRM_CLK              CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_B_EN_PIN                         GPIO_PINS_2
#define MOTOR_B_EN_GPIO                        GPIOD
#define MOTOR_B_EN_GPIO_CRM_CLK                CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_B_DIR_PIN                        GPIO_PINS_3
#define MOTOR_B_DIR_GPIO                       GPIOD
#define MOTOR_B_DIR_GPIO_CRM_CLK               CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_B_STEP_PIN                       GPIO_PINS_13
#define MOTOR_B_STEP_GPIO                      GPIOD
#define MOTOR_B_STEP_GPIO_CRM_CLK              CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_C_EN_PIN                         GPIO_PINS_4
#define MOTOR_C_EN_GPIO                        GPIOD
#define MOTOR_C_EN_GPIO_CRM_CLK                CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_C_DIR_PIN                        GPIO_PINS_5
#define MOTOR_C_DIR_GPIO                       GPIOD
#define MOTOR_C_DIR_GPIO_CRM_CLK               CRM_GPIOD_PERIPH_CLOCK

#define MOTOR_C_STEP_PIN                       GPIO_PINS_14
#define MOTOR_C_STEP_GPIO                      GPIOD
#define MOTOR_C_STEP_GPIO_CRM_CLK              CRM_GPIOD_PERIPH_CLOCK



#define ACTUATORA_F_PIN                  				GPIO_PINS_6
#define ACTUATORA_F_GPIO                      	GPIOC
#define ACTUATORA_F_GPIO_CRM_CLK              	CRM_GPIOC_PERIPH_CLOCK

#define ACTUATORA_R_PIN                  				GPIO_PINS_7
#define ACTUATORA_R_GPIO                      	GPIOC
#define ACTUATORA_R_GPIO_CRM_CLK              	CRM_GPIOC_PERIPH_CLOCK

#define ACTUATORB_F_PIN                  				GPIO_PINS_8
#define ACTUATORB_F_GPIO                      	GPIOC
#define ACTUATORB_F_GPIO_CRM_CLK              	CRM_GPIOC_PERIPH_CLOCK

#define ACTUATORB_R_PIN                  				GPIO_PINS_9
#define ACTUATORB_R_GPIO                      	GPIOC
#define ACTUATORB_R_GPIO_CRM_CLK              	CRM_GPIOC_PERIPH_CLOCK

#define ACTUATORA_F_TOOGLE					ACTUATORA_F_GPIO->odt ^= ACTUATORA_F_PIN
#define ACTUATORA_R_TOOGLE					ACTUATORA_R_GPIO->odt ^= ACTUATORA_R_PIN

void stepmotorCtrlGpioInit(void);		//�������ų�ʼ��
void actuatorGpioInit(void);		//�綯�Ƹ����ų�ʼ��
#endif

