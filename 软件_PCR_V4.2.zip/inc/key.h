#ifndef __KEY_H_
#define __KEY_H_
#include "at32f435_437_int.h"

#define EXINT_BUTTON0_PIN                         SCFG_PINS_SOURCE11
#define EXINT_BUTTON0_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON0_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON1_PIN                         SCFG_PINS_SOURCE1
#define EXINT_BUTTON1_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON1_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON2_PIN                         SCFG_PINS_SOURCE2
#define EXINT_BUTTON2_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON2_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON3_PIN                         SCFG_PINS_SOURCE3
#define EXINT_BUTTON3_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON3_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON4_PIN                         SCFG_PINS_SOURCE4
#define EXINT_BUTTON4_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON4_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON5_PIN                         SCFG_PINS_SOURCE5
#define EXINT_BUTTON5_PORT                        SCFG_PORT_SOURCE_GPIOE
#define EXINT_BUTTON5_CRM_CLK                     CRM_GPIOE_PERIPH_CLOCK

#define EXINT_BUTTON0_LINE                        EXINT_LINE_11
#define EXINT_BUTTON1_LINE                        EXINT_LINE_1
#define EXINT_BUTTON2_LINE                        EXINT_LINE_2
#define EXINT_BUTTON3_LINE                        EXINT_LINE_3
#define EXINT_BUTTON4_LINE                        EXINT_LINE_4
#define EXINT_BUTTON5_LINE                        EXINT_LINE_5


#define EXINT_BUTTON0_IRQn                        EXINT15_10_IRQn
#define EXINT_BUTTON1_IRQn                        EXINT1_IRQn
#define EXINT_BUTTON2_IRQn                        EXINT2_IRQn
#define EXINT_BUTTON3_IRQn                        EXINT3_IRQn
#define EXINT_BUTTON4_IRQn                        EXINT4_IRQn
#define EXINT_BUTTON5_IRQn                        EXINT9_5_IRQn

#define EXINT_BUTTON0_IRQHandler                  EXINT15_10_IRQHandler
#define EXINT_BUTTON1_IRQHandler                  EXINT1_IRQHandler
#define EXINT_BUTTON2_IRQHandler                  EXINT2_IRQHandler
#define EXINT_BUTTON3_IRQHandler                  EXINT3_IRQHandler
#define EXINT_BUTTON4_IRQHandler                  EXINT4_IRQHandler
#define EXINT_BUTTON5_IRQHandler                  EXINT9_5_IRQHandler

void key_exint_config(void);

#endif

